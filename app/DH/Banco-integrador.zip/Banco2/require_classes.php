<?php
require_once "Contratos/Liquidable.php";

require_once "Entidades/Cuentas/Cuenta.php";
require_once "Entidades/Cuentas/Classic.php";
//require_once "Entidades/Cuentas/Gold.php";
//require_once "Entidades/Cuentas/Platinum.php";
//require_once "Entidades/Cuentas/Black.php";

require_once "Entidades/Clientes/Cliente.php";
//require_once "Entidades/Clientes/Pyme.php";
require_once "Entidades/Clientes/Persona.php";
//require_once "Entidades/Clientes/Multinacional.php";