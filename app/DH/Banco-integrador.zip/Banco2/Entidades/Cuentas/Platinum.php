<?php

class Platinum extends Cuenta
{

}