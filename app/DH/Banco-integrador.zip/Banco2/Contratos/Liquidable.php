<?php

interface Liquidable {
	public function liquidarHaberes(Persona $persona, $monto);
}