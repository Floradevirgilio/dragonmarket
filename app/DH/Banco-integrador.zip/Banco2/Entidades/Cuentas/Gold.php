<?php

class Gold extends Cuenta
{

}