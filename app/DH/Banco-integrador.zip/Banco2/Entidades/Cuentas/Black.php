<?php

class Black extends Cuenta
{

}